/**
 * 		Classes for Simple Math Functionality, such as Min, Max, WeightedAverage,
 * Scientific Notation, etc.
 * <hr>
 * <address><a href="mailto:sdkamvar@stanford.edu">Sepandar David Kamvar</a></address>
 * <!-- Created: Thu Oct 31 10:33:43 PST 2002 -->
 * <!-- hhmts start -->
 * Last modified: Thu Oct 31 11:07:47 PST 2002
 * <!-- hhmts end -->
 */
package edu.stanford.nlp.math;