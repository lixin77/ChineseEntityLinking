/**
 * <body>
 * <p>This package contains various types and interfaces used when
 * parsing TokensRegex patterns and rules.</p>
 * @author Angel Chang (angelx@stanford.edu)
 * </body>
 */
package edu.stanford.nlp.ling.tokensregex.types;